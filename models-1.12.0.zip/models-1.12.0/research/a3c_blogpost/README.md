# A3C Blog Post
In order to run this code, you will need the following prerequisites:

* [OpenAI Gym](https://github.com/openai/gym) - `pip install gym`
* pyglet - `pip intall pyglet` 
* [TensorFlow](https://www.tensorflow.org/install/) - `pip install tensorflow`
